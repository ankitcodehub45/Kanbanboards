const date = new Date().toJSON();
console.log(date);
console.log(new Date());
