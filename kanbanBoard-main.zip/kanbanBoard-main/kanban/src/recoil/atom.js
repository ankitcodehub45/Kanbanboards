import {atom}  from 'recoil';

export const ListData = atom({
    key : "ListData",
    default:[]
})
export const dialogBox = atom({
    key: "dialogBox",
    default: true,
  });